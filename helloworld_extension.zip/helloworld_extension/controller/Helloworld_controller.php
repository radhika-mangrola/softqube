<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Helloworld_controller extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('unzip');
        $this->load->helper(array('form', 'url'));
    }

    function index() {
        $this->load->view('Helloworld/Helloworld_view');
    }

}

/* End of file rental_category.php */
/* Location: ./application/controllers/rental_category.php */
